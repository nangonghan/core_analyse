self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "59229b90fdda33ad281c7f09fe4cb2df",
    "url": "./index.html"
  },
  {
    "revision": "e2f55ff8e65ab0cea94c",
    "url": "./static/css/2.1bd2ab2f.chunk.css"
  },
  {
    "revision": "1f64f6cbaff554e53452",
    "url": "./static/css/main.0dc19af1.chunk.css"
  },
  {
    "revision": "e2f55ff8e65ab0cea94c",
    "url": "./static/js/2.b09717f0.chunk.js"
  },
  {
    "revision": "74b5b99a348fedd13ab1cb018bec8748",
    "url": "./static/js/2.b09717f0.chunk.js.LICENSE.txt"
  },
  {
    "revision": "1f64f6cbaff554e53452",
    "url": "./static/js/main.c25a1350.chunk.js"
  },
  {
    "revision": "a2b093908b6b1ddd9337",
    "url": "./static/js/runtime-main.4cee0d13.js"
  },
  {
    "revision": "b1be81eae2787b207d7cf78b9fbf5644",
    "url": "./static/media/logo.b1be81ea.png"
  },
  {
    "revision": "accb270e2c93ddb80ca67db6011ea780",
    "url": "./static/media/wallpaper3.accb270e.jpg"
  }
]);